package com.kaizen.shubhambhavatu.service;

import com.kaizen.shubhambhavatu.AbstractIntegrationTest;
import com.kaizen.shubhambhavatu.constants.*;
import com.kaizen.shubhambhavatu.dto.BirthPlaceDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsCreateInDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsInDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsOutDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsUpdateInDto;
import com.kaizen.shubhambhavatu.dto.physical_details.PhysicalDetailsOutDto;
import com.kaizen.shubhambhavatu.dto.physical_details.PhysicalDetailsUpdateInDto;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;

import static com.kaizen.shubhambhavatu.utils.CandidateDetailsUtil.getPersonalDetailsCreateInDto;
import static com.kaizen.shubhambhavatu.utils.CandidateDetailsUtil.getPersonalDetailsUpdateInDto;
import static com.kaizen.shubhambhavatu.utils.TestDataUtils.randomEnumName;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric;
import static org.apache.commons.lang3.RandomUtils.nextDouble;
import static org.apache.commons.lang3.RandomUtils.nextInt;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.*;

public class CandidateServiceTest extends AbstractIntegrationTest {

    @Autowired
    private CandidateServiceImpl candidateService;

    @Test
    public void testRegisterCandidateWithValidRequest() {
        PersonalDetailsCreateInDto inDto = getPersonalDetailsCreateInDto();
        PersonalDetailsOutDto outDto = candidateService.registerCandidate(inDto);
        assertPersonalDetailsOutDto(inDto, outDto);
    }

    @Test
    public void testRegisterCandidateWithInvalidCombinationOfDistrictIdAndTehsil() {
        PersonalDetailsCreateInDto inDto = getPersonalDetailsCreateInDto();
        inDto.getBirthPlaceDto().setTehsilId(7L);
        EntityNotFoundException exception = assertThrows(
                EntityNotFoundException.class,
                () -> candidateService.registerCandidate(inDto)
        );
        assertEquals(String.format("Tehsil with tehsilId %S and districtId %S does not exists", inDto.getBirthPlaceDto().getTehsilId(), inDto.getBirthPlaceDto().getDistrictId()), exception.getMessage());
    }

    @Test
    public void testRegisterCandidateWithInvalidDistrictIdAndTehsilIdIsNull() {
        PersonalDetailsCreateInDto inDto = getPersonalDetailsCreateInDto();
        inDto.getBirthPlaceDto().setDistrictId(500000L);
        inDto.getBirthPlaceDto().setTehsilId(null);
        EntityNotFoundException exception = assertThrows(
                EntityNotFoundException.class,
                () -> candidateService.registerCandidate(inDto)
        );
        assertEquals(String.format("District with districtId %S does not exists", inDto.getBirthPlaceDto().getDistrictId()), exception.getMessage());
    }

    @Test(expected = EntityExistsException.class)
    public void testRegisterCandidateWhenCandidateAlreadyExists() {
        PersonalDetailsCreateInDto inDto = getPersonalDetailsCreateInDto();
        PersonalDetailsOutDto outDto = candidateService.registerCandidate(inDto);
        assertPersonalDetailsOutDto(inDto, outDto);
        candidateService.registerCandidate(inDto);
    }

    @Test
    @Transactional
    public void testUpdatePersonalDetailsWithValidData() {
        PersonalDetailsCreateInDto inDto = getPersonalDetailsCreateInDto();
        PersonalDetailsOutDto outDto = candidateService.registerCandidate(inDto);
        PersonalDetailsUpdateInDto updateInDto = getPersonalDetailsUpdateInDto(outDto.getCandidateNumber());
        PersonalDetailsOutDto updateOutDto = candidateService.updatePersonalDetails(updateInDto);
        assertPersonalDetailsOutDto(updateInDto, updateOutDto);
        assertFirstNameLastNameAndBirthDate(inDto, updateOutDto);
    }

    @Test
    public void testUpdatePersonalDetailsWithValidDataAndWhenBirthPlaceOfExistingCandidateIsNull() {
        PersonalDetailsCreateInDto inDto = getPersonalDetailsCreateInDto();
        inDto.setBirthPlaceDto(null);
        PersonalDetailsOutDto outDto = candidateService.registerCandidate(inDto);
        PersonalDetailsUpdateInDto updateInDto = getPersonalDetailsUpdateInDto(outDto.getCandidateNumber());
        PersonalDetailsOutDto updateOutDto = candidateService.updatePersonalDetails(updateInDto);
        assertPersonalDetailsOutDto(updateInDto, updateOutDto);
        assertFirstNameLastNameAndBirthDate(inDto, updateOutDto);
    }

    @Test
    @Transactional
    public void testUpdatePersonalDetailsWithValidDataAndWithInvalidDistrictId() {
        PersonalDetailsCreateInDto inDto = getPersonalDetailsCreateInDto();
        inDto.setBirthPlaceDto(null);
        PersonalDetailsOutDto outDto = candidateService.registerCandidate(inDto);
        PersonalDetailsUpdateInDto updateInDto = getPersonalDetailsUpdateInDto(outDto.getCandidateNumber());
        updateInDto.getBirthPlaceDto().setDistrictId(500000L);
        updateInDto.getBirthPlaceDto().setTehsilId(null);
        EntityNotFoundException exception = assertThrows(
                EntityNotFoundException.class,
                () -> candidateService.updatePersonalDetails(updateInDto)
        );
        assertEquals(String.format("District with districtId %S does not exists", updateInDto.getBirthPlaceDto().getDistrictId()), exception.getMessage());
    }

    @Test
    @Transactional
    public void testUpdatePersonalDetailsWithValidDataAndInvalidCombinationOfDistrictAndTehsil() {
        PersonalDetailsCreateInDto inDto = getPersonalDetailsCreateInDto();
        inDto.setBirthPlaceDto(null);
        PersonalDetailsOutDto outDto = candidateService.registerCandidate(inDto);
        PersonalDetailsUpdateInDto updateInDto = getPersonalDetailsUpdateInDto(outDto.getCandidateNumber());
        updateInDto.getBirthPlaceDto().setDistrictId(500000L);
        updateInDto.getBirthPlaceDto().setTehsilId(10000L);
        EntityNotFoundException exception = assertThrows(
                EntityNotFoundException.class,
                () -> candidateService.updatePersonalDetails(updateInDto)
        );
        assertEquals(String.format("Tehsil with tehsilId %S and districtId %S does not exists", updateInDto.getBirthPlaceDto().getTehsilId(), updateInDto.getBirthPlaceDto().getDistrictId()), exception.getMessage());
    }

    @Test(expected = EntityNotFoundException.class)
    public void testUpdatePersonalDetailsWhenCandidateDoesNotExists() {
        PersonalDetailsUpdateInDto updateInDto = getPersonalDetailsUpdateInDto(randomAlphanumeric(10));
        candidateService.updatePersonalDetails(updateInDto);
    }

    @Test
    public void testUpdatePhysicalDetailsWithValidData() {
        PersonalDetailsCreateInDto inDto = getPersonalDetailsCreateInDto();
        PersonalDetailsOutDto outDto = candidateService.registerCandidate(inDto);
        PhysicalDetailsUpdateInDto updateInDto = getPhysicalDetailsUpdateInDto(outDto.getCandidateNumber());
        PhysicalDetailsOutDto physicalDetailsOutDto = candidateService.updatePhysicalDetails(updateInDto);
        assertPhysicalDetailsDto(updateInDto, physicalDetailsOutDto);
    }

    @Test(expected = EntityNotFoundException.class)
    public void testUpdatePhysicalDetailsWithInvalidCandidateNumber() {
        candidateService.updatePhysicalDetails(getPhysicalDetailsUpdateInDto(randomAlphanumeric(10)));
    }

    public static PhysicalDetailsUpdateInDto getPhysicalDetailsUpdateInDto(String candidateNumber) {
        PhysicalDetailsUpdateInDto updateInDto = new PhysicalDetailsUpdateInDto();
        updateInDto.setCandidateNumber(candidateNumber);
        updateInDto.setBloodGroup(randomEnumName(BloodGroup.class));
        updateInDto.setContactLenses(randomEnumName(YesNo.class));
        updateInDto.setDrinking(randomEnumName(DrinkingSmoking.class));
        updateInDto.setSmoking(randomEnumName(DrinkingSmoking.class));
        updateInDto.setPhysicalStatus(randomEnumName(PhysicalStatus.class));
        updateInDto.setDisabilityDescription(randomAlphabetic(25));
        updateInDto.setEatingHabits(randomEnumName(EatingHabits.class));
        updateInDto.setHairColour(randomEnumName(HairColour.class));
        updateInDto.setEyeColour(randomEnumName(EyeColour.class));
        updateInDto.setSkinColour(randomEnumName(SkinType.class));
        updateInDto.setHeight(nextDouble());
        updateInDto.setWeight(nextInt());
        return updateInDto;
    }

    private static void assertPersonalDetailsOutDto(PersonalDetailsInDto inDto, PersonalDetailsOutDto outDto) {
        assertNotNull(outDto.getCandidateNumber());
        if (inDto instanceof PersonalDetailsCreateInDto) {
            assertFirstNameLastNameAndBirthDate((PersonalDetailsCreateInDto) inDto, outDto);
        }
        assertEquals(inDto.getMiddleName(), outDto.getMiddleName());
        assertEquals(inDto.getBirthTime(), outDto.getBirthTime());
        assertEquals(inDto.getContactNumber(), outDto.getContactNumber());
        assertEquals(inDto.getEmailId(), outDto.getEmailId());
        assertEquals(inDto.getGender(), outDto.getGender());
        assertEquals(inDto.getMaritalStatus(), outDto.getMaritalStatus());
        assertEquals(inDto.getMotherTongueId(), outDto.getMotherTongueId());
        assertEquals(inDto.getNumberOfChildren(), outDto.getNumberOfChildren());
        if (nonNull(inDto.getBirthPlaceDto()) && nonNull(outDto.getBirthPlaceDto())) {
            assertBirthPlaceDto(inDto.getBirthPlaceDto(), outDto.getBirthPlaceDto());
        }
    }

    private static void assertFirstNameLastNameAndBirthDate(PersonalDetailsCreateInDto inDto, PersonalDetailsOutDto outDto) {
        assertEquals(inDto.getBirthDate(), outDto.getBirthDate());
        assertEquals(inDto.getFirstName(), outDto.getFirstName());
        assertEquals(inDto.getLastName(), outDto.getLastName());
    }

    private static void assertBirthPlaceDto(BirthPlaceDto inDto, BirthPlaceDto outDto) {
        assertEquals(inDto.getDistrictId(), outDto.getDistrictId());
        assertEquals(inDto.getTehsilId(), outDto.getTehsilId());
        assertEquals(inDto.getPinCode(), outDto.getPinCode());
        assertEquals(inDto.getTown(), outDto.getTown());
    }

    private static void assertPhysicalDetailsDto(PhysicalDetailsUpdateInDto inDto, PhysicalDetailsOutDto outDto) {
        assertEquals(inDto.getCandidateNumber(), outDto.getCandidateNumber());
        assertEquals(inDto.getBloodGroup(), outDto.getBloodGroup());
        assertEquals(inDto.getContactLenses(), outDto.getContactLenses());
        assertEquals(inDto.getDrinking(), outDto.getDrinking());
        assertEquals(inDto.getSmoking(), outDto.getSmoking());
        assertEquals(inDto.getEatingHabits(), outDto.getEatingHabits());
        assertEquals(inDto.getEyeColour(), outDto.getEyeColour());
        assertEquals(inDto.getSkinColour(), outDto.getSkinColour());
        assertEquals(inDto.getHairColour(), outDto.getHairColour());
        assertThat(inDto.getHeight(), equalTo(outDto.getHeight()));
        assertEquals(inDto.getHeight(), outDto.getHeight(), 2d);
        assertEquals(inDto.getWeight(), outDto.getWeight());
        assertEquals(inDto.getPhysicalStatus(), outDto.getPhysicalStatus());
        assertEquals(inDto.getBuild(), outDto.getBuild());
        assertEquals(inDto.getDisabilityDescription(), outDto.getDisabilityDescription());
    }

    //ToDO - 1. Add test for Null birthPlaceDto for updateCandidate method
    //ToDo - 2. Add test (as well as code) for tehsilId only in birthPlaceDto
}
