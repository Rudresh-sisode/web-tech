package com.kaizen.shubhambhavatu.service.tehsil;

import com.kaizen.shubhambhavatu.AbstractIntegrationTest;
import com.kaizen.shubhambhavatu.entity.master.Tehsil;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.EntityNotFoundException;

public class TehsilServiceTest extends AbstractIntegrationTest {

    @Autowired
    private TehsilServiceImpl tehsilService;

    @Test(expected = EntityNotFoundException.class)
    public void testGetTehsilById() {
        Tehsil tehsil = tehsilService.getTehsilById(500l);
    }
}
