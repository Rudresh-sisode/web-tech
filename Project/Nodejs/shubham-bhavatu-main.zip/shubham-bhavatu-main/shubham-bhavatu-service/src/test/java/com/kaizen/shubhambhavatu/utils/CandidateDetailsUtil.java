package com.kaizen.shubhambhavatu.utils;

import com.kaizen.shubhambhavatu.constants.Gender;
import com.kaizen.shubhambhavatu.constants.MaritalStatus;
import com.kaizen.shubhambhavatu.dto.BirthPlaceDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsCreateInDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsInDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsUpdateInDto;

import static com.kaizen.shubhambhavatu.utils.TestDataUtils.randomEnumName;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang3.RandomStringUtils.randomNumeric;

public class CandidateDetailsUtil {

    public static PersonalDetailsCreateInDto getPersonalDetailsCreateInDto() {
        PersonalDetailsCreateInDto personalDetailsDto = (PersonalDetailsCreateInDto) getPersonalDetailsDto(new PersonalDetailsCreateInDto());
        personalDetailsDto.setFirstName(randomAlphabetic(8));
        personalDetailsDto.setLastName(randomAlphabetic(10));
        personalDetailsDto.setBirthDate("12-12-2000");
        return personalDetailsDto;
    }

    public static PersonalDetailsUpdateInDto getPersonalDetailsUpdateInDto(String candidateNumber) {
        PersonalDetailsUpdateInDto updateInDto = (PersonalDetailsUpdateInDto) getPersonalDetailsDto(new PersonalDetailsUpdateInDto());
        updateInDto.setCandidateNumber(candidateNumber);
        return updateInDto;
    }

    public static PersonalDetailsInDto getPersonalDetailsDto(PersonalDetailsInDto personalDetailsInDto) {
        personalDetailsInDto.setMiddleName(randomAlphabetic(9));
        personalDetailsInDto.setContactNumber(randomNumeric(10));
        personalDetailsInDto.setEmailId("test@test.com");
        personalDetailsInDto.setBirthTime(randomNumeric(5));
        personalDetailsInDto.setMaritalStatus(randomEnumName(MaritalStatus.class));
        personalDetailsInDto.setGender(randomEnumName(Gender.class));
        personalDetailsInDto.setBirthPlaceDto(getBirthPlaceDto());
        return personalDetailsInDto;
    }

    public static BirthPlaceDto getBirthPlaceDto() {
        BirthPlaceDto birthPlaceDto = new BirthPlaceDto();
        birthPlaceDto.setPinCode(randomNumeric(6));
        birthPlaceDto.setTown(randomAlphabetic(10));
        birthPlaceDto.setDistrictId(392L);
        birthPlaceDto.setTehsilId(5L);
        return birthPlaceDto;
    }

}
