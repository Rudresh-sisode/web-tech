package com.kaizen.shubhambhavatu;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.kaizen.shubhambhavatu")
public class Application {
}
