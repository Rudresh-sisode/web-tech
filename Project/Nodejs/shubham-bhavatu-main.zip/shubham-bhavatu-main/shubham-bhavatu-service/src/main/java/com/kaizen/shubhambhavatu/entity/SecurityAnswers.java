package com.kaizen.shubhambhavatu.entity;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "security_answers")
@Data
public class SecurityAnswers {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


}
