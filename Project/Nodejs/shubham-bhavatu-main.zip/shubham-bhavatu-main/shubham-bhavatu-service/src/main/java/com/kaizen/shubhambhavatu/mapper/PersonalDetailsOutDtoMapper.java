package com.kaizen.shubhambhavatu.mapper;

import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsOutDto;
import com.kaizen.shubhambhavatu.entity.CandidateDetails;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PersonalDetailsOutDtoMapper {
    @Mapping(target = "birthPlaceDto.districtId", source = "personalDetails.birthPlace.districtId")
    @Mapping(target = "birthPlaceDto.tehsilId", source = "personalDetails.birthPlace.tehsilId")
    @Mapping(target = "birthPlaceDto.pinCode", source = "personalDetails.birthPlace.pinCode")
    @Mapping(target = "birthPlaceDto.town", source = "personalDetails.birthPlace.town")
    @Mapping(target = "firstName", source = "personalDetails.firstName")
    @Mapping(target = "middleName", source = "personalDetails.middleName")
    @Mapping(target = "lastName", source = "personalDetails.lastName")
    @Mapping(target = "birthDate", source = "personalDetails.birthDate")
    @Mapping(target = "gender", source = "personalDetails.gender")
    @Mapping(target = "maritalStatus", source = "personalDetails.maritalStatus")
    @Mapping(target = "numberOfChildren", source = "personalDetails.numberOfChildren")
    @Mapping(target = "motherTongueId", source = "personalDetails.motherTongueId")
    @Mapping(target = "birthTime", source = "personalDetails.birthTime")
    @Mapping(target = "emailId", source = "personalDetails.emailId")
    @Mapping(target = "contactNumber", source = "personalDetails.contactNumber")
    PersonalDetailsOutDto map(CandidateDetails candidateDetails);
}
