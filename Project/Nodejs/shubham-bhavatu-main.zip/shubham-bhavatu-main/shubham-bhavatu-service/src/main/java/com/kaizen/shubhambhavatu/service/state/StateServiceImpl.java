package com.kaizen.shubhambhavatu.service.state;

import com.kaizen.shubhambhavatu.entity.master.State;
import com.kaizen.shubhambhavatu.repository.StateRepository;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.Optional;

@Service
public class StateServiceImpl implements StateService{

    private final StateRepository stateRepository;

    public StateServiceImpl(StateRepository stateRepository) {
        this.stateRepository = stateRepository;
    }

    @Override
    public State getStateById(Long id) {
        Optional<State> stateOptional = stateRepository.findById(id);
        return stateOptional.orElseThrow(() ->new EntityNotFoundException("State with id "+ id +" does not exists"));
    }
}
