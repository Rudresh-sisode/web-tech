package com.kaizen.shubhambhavatu.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class TehsilInDto {
    private String districtName;
    private List<String> tehsilNames;
    private int districtId;
}
