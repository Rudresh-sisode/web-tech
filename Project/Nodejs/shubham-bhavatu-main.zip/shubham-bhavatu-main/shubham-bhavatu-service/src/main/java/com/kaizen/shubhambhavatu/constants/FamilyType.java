package com.kaizen.shubhambhavatu.constants;

public enum FamilyType {
    NUCLEUS("Nucleus"), JOINT("Joint");

    private final String value;

    FamilyType(String value) {
        this.value = value;
    }
}
