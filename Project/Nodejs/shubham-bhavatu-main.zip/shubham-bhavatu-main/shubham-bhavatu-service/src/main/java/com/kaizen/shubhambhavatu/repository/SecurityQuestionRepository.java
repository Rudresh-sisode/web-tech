package com.kaizen.shubhambhavatu.repository;

import com.kaizen.shubhambhavatu.entity.SecurityQuestion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SecurityQuestionRepository extends JpaRepository<SecurityQuestion, Long> {
    @Query("SELECT question FROM SecurityQuestion question WHERE isActive = true")
    List<SecurityQuestion> getActiveSecurityQuestions();
}
