package com.kaizen.shubhambhavatu.constants;

import java.util.Arrays;
import java.util.Optional;

public enum BloodGroup {
    A_POSITIVE("A+"),
    A_NEGATIVE("A-"),
    B_POSITIVE("B+"),
    B_NEGATIVE("B-"),
    AB_POSITIVE("AB+"),
    AB_NEGATIVE("AB-"),
    O_POSITIVE("O+"),
    O_NEGATIVE("O-");

    private final String value;

    BloodGroup(String value) {
        this.value = value;
    }

    public static BloodGroup findByValue(String value) {
        Optional<BloodGroup> bloodGroupOptional = Arrays.stream(BloodGroup.values()).filter(bloodGroup -> bloodGroup.getValue().equals(value)).findFirst();
        return bloodGroupOptional.orElseThrow(() -> new UnsupportedOperationException(value + "is invalid for blood group"));
    }

    public String getValue() {
        return value;
    }

}
