package com.kaizen.shubhambhavatu.dto.physical_details;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PhysicalDetailsOutDto extends PhysicalDetailsDto {
    private String candidateNumber;
}
