package com.kaizen.shubhambhavatu.service;

import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsCreateInDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsOutDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsUpdateInDto;
import com.kaizen.shubhambhavatu.dto.physical_details.PhysicalDetailsOutDto;
import com.kaizen.shubhambhavatu.dto.physical_details.PhysicalDetailsUpdateInDto;
import com.kaizen.shubhambhavatu.entity.*;
import com.kaizen.shubhambhavatu.entity.master.Tehsil;
import com.kaizen.shubhambhavatu.mapper.PersonalDetailsEntityMapper;
import com.kaizen.shubhambhavatu.mapper.PersonalDetailsOutDtoMapper;
import com.kaizen.shubhambhavatu.mapper.PhysicalDetailsDtoMapper;
import com.kaizen.shubhambhavatu.mapper.PhysicalDetailsEntityMapper;
import com.kaizen.shubhambhavatu.repository.CandidateDetailsRepository;
import com.kaizen.shubhambhavatu.service.district.DistrictService;
import com.kaizen.shubhambhavatu.service.tehsil.TehsilService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityNotFoundException;
import java.util.Optional;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;

@Service
public class CandidateServiceImpl implements CandidateService {

    private final CandidateDetailsRepository candidateDetailsRepository;
    private final PersonalDetailsEntityMapper personalDetailsEntityMapper;
    private final PersonalDetailsOutDtoMapper personalDetailsOutDtoMapper;
    private final PhysicalDetailsEntityMapper physicalDetailsEntityMapper;
    private final PhysicalDetailsDtoMapper physicalDetailsDtoMapper;
    private final DistrictService districtService;
    private final TehsilService tehsilService;

    @Autowired
    public CandidateServiceImpl(CandidateDetailsRepository candidateDetailsRepository,
                                PersonalDetailsEntityMapper personalDetailsEntityMapper,
                                PersonalDetailsOutDtoMapper personalDetailsOutDtoMapper,
                                PhysicalDetailsEntityMapper physicalDetailsEntityMapper,
                                PhysicalDetailsDtoMapper physicalDetailsDtoMapper, DistrictService districtService, TehsilService tehsilService) {
        this.candidateDetailsRepository = candidateDetailsRepository;
        this.personalDetailsEntityMapper = personalDetailsEntityMapper;
        this.personalDetailsOutDtoMapper = personalDetailsOutDtoMapper;
        this.physicalDetailsEntityMapper = physicalDetailsEntityMapper;
        this.physicalDetailsDtoMapper = physicalDetailsDtoMapper;
        this.districtService = districtService;
        this.tehsilService = tehsilService;
    }

    @Override
    public PersonalDetailsOutDto registerCandidate(PersonalDetailsCreateInDto personalDetailsDto) {
        PersonalDetails personalDetails = personalDetailsEntityMapper.map(personalDetailsDto);
        if (nonNull(personalDetails.getBirthPlace())) {
            validateDistrictAndTehsil(personalDetails.getBirthPlace());
            personalDetails.getBirthPlace().setCreatedBy(personalDetailsDto.getCreatedBy());
        }
        Optional<CandidateDetails> candidateDetailsOptional = candidateDetailsRepository.findByPersonalDetailsFirstNameAndPersonalDetailsLastNameAndPersonalDetailsBirthDate(personalDetails.getFirstName(), personalDetails.getLastName(), personalDetails.getBirthDate());
        if (candidateDetailsOptional.isPresent()) {
            throw new EntityExistsException("Candidate already exists");
        }
        CandidateDetails createdCandidate = createCandidate(personalDetailsDto, personalDetails);
        return personalDetailsOutDtoMapper.map(createdCandidate);
    }

    @Override
    public PersonalDetailsOutDto updatePersonalDetails(PersonalDetailsUpdateInDto personalDetailsUpdateInDto) {
        Optional<CandidateDetails> candidateDetailsOptional = candidateDetailsRepository.findByCandidateNumber(personalDetailsUpdateInDto.getCandidateNumber());
        if (candidateDetailsOptional.isPresent()) {
            CandidateDetails existingCandidate = candidateDetailsOptional.get();
            PersonalDetails toUpdate = personalDetailsEntityMapper.mapUpdate(personalDetailsUpdateInDto);
            if (nonNull(toUpdate.getBirthPlace())) {
                BirthPlace birthPlace = toUpdate.getBirthPlace();
                if (isBirthPlaceUpdated(existingCandidate.getPersonalDetails().getBirthPlace(), birthPlace)) {
                    validateDistrictAndTehsil(birthPlace);
                }
                birthPlace.setUpdatedBy(personalDetailsUpdateInDto.getUpdatedBy());
            }
            doUpdateExistingPersonalDetails(existingCandidate.getPersonalDetails(), toUpdate);
            existingCandidate.setUpdatedBy(personalDetailsUpdateInDto.getUpdatedBy());
            CandidateDetails updatedCandidate = candidateDetailsRepository.saveAndFlush(existingCandidate);
            return personalDetailsOutDtoMapper.map(updatedCandidate);
        } else {
            throw new EntityNotFoundException("Candidate with candidate number " + personalDetailsUpdateInDto.getCandidateNumber() + " does not exists.");
        }
    }

    @Override
    public PhysicalDetailsOutDto updatePhysicalDetails(PhysicalDetailsUpdateInDto physicalDetailsUpdateInDto) {
        Optional<CandidateDetails> candidateDetailsOptional = candidateDetailsRepository.findByCandidateNumber(physicalDetailsUpdateInDto.getCandidateNumber());
        if (candidateDetailsOptional.isPresent()) {
            CandidateDetails existingCandidate = candidateDetailsOptional.get();
            PhysicalDetails toUpdate = physicalDetailsEntityMapper.map(physicalDetailsUpdateInDto);

            doUpdateExistingPhysicalDetails(existingCandidate.getPhysicalDetails(), toUpdate);
            existingCandidate.setUpdatedBy(physicalDetailsUpdateInDto.getUpdatedBy());
            CandidateDetails updatedCandidate = candidateDetailsRepository.saveAndFlush(existingCandidate);
            return physicalDetailsDtoMapper.map(updatedCandidate);
        } else {
            throw new EntityNotFoundException("Candidate with candidate number " + physicalDetailsUpdateInDto.getCandidateNumber() + " does not exists.");
        }
    }

    private String generateCandidateNumber() {
        return randomAlphabetic(4).toUpperCase()
                + candidateDetailsRepository.getNextCandidateNumberSequence();
    }

    private void validateDistrictAndTehsil(BirthPlace birthPlace) {
        if (nonNull(birthPlace.getDistrictId())) {
            if (nonNull(birthPlace.getTehsilId())) {
                Optional<Tehsil> tehsilOptional = tehsilService.getTehsilByIdAndDistrictId(birthPlace.getTehsilId(), birthPlace.getDistrictId());
                if (!tehsilOptional.isPresent()) {
                    throw new EntityNotFoundException("Tehsil with tehsilId " + birthPlace.getTehsilId() + " and districtId " + birthPlace.getDistrictId() + " does not exists");
                }
            } else {
                Optional<District> districtOptional = districtService.getDistrict(birthPlace.getDistrictId());
                if (!districtOptional.isPresent()) {
                    throw new EntityNotFoundException("District with districtId " + birthPlace.getDistrictId() + " does not exists");
                }
            }
        }
    }

    private boolean isBirthPlaceUpdated(BirthPlace existing, BirthPlace toUpdate) {
        if (isNull(existing)) {
            return true;
        } else
            return !(existing.getDistrictId().equals(toUpdate.getDistrictId()) && existing.getTehsilId().equals(toUpdate.getTehsilId()));
    }

    private CandidateDetails createCandidate(PersonalDetailsCreateInDto personalDetailsDto, PersonalDetails personalDetails) {
        CandidateDetails candidateDetails = new CandidateDetails();
        candidateDetails.setPersonalDetails(personalDetails);
        candidateDetails.setCreatedBy(personalDetailsDto.getCreatedBy());
        setDefaultCandidateDetails(candidateDetails);
        candidateDetails.setCandidateNumber(generateCandidateNumber());
        return candidateDetailsRepository.saveAndFlush(candidateDetails);
    }


    private void doUpdateExistingPersonalDetails(PersonalDetails existing, PersonalDetails toUpdate) {
        existing.setMiddleName(toUpdate.getMiddleName());
        existing.setBirthTime(toUpdate.getBirthTime());
        existing.setContactNumber(toUpdate.getContactNumber());
        existing.setEmailId(toUpdate.getEmailId());
        existing.setGender(toUpdate.getGender());
        existing.setMaritalStatus(toUpdate.getMaritalStatus());
        existing.setMotherTongueId(toUpdate.getMotherTongueId());
        existing.setNativePlace(toUpdate.getNativePlace());
        existing.setNumberOfChildren(toUpdate.getNumberOfChildren());
        if (existing.getBirthPlace() == null) {
            existing.setBirthPlace(toUpdate.getBirthPlace());
        } else if (toUpdate.getBirthPlace() == null) {
            existing.setBirthPlace(null);
        } else {
            doUpdateExistingBirthPlace(existing.getBirthPlace(), toUpdate.getBirthPlace());
        }
    }

    private void doUpdateExistingPhysicalDetails(PhysicalDetails existing, PhysicalDetails toUpdate) {
        existing.setHeight(toUpdate.getHeight());
        existing.setWeight(toUpdate.getWeight());
        existing.setBloodGroup(toUpdate.getBloodGroup());
        existing.setContactLenses(toUpdate.getContactLenses());
        existing.setSmoking(toUpdate.getSmoking());
        existing.setDrinking(toUpdate.getDrinking());
        existing.setEyeColour(toUpdate.getEyeColour());
        existing.setHairColour(toUpdate.getHairColour());
        existing.setSkinColour(toUpdate.getSkinColour());
        existing.setEatingHabits(toUpdate.getEatingHabits());
        existing.setPhysicalStatus(toUpdate.getPhysicalStatus());
        existing.setDisabilityDescription(toUpdate.getDisabilityDescription());
        existing.setBuild(toUpdate.getBuild());
    }

    private void doUpdateExistingBirthPlace(BirthPlace existing, BirthPlace toUpdate) {
        existing.setDistrictId(toUpdate.getDistrictId());
        existing.setPinCode(toUpdate.getPinCode());
        existing.setTown(toUpdate.getTown());
        existing.setTehsilId(toUpdate.getTehsilId());
        existing.setUpdatedBy(toUpdate.getUpdatedBy());
    }

    private void setDefaultCandidateDetails(CandidateDetails candidateDetails) {
        PhysicalDetails physicalDetails = new PhysicalDetails();
        physicalDetails.setHeight(0d);
        physicalDetails.setWeight(0);
        candidateDetails.setPhysicalDetails(physicalDetails);
    }
}
