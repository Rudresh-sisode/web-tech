package com.kaizen.shubhambhavatu.repository;

import com.kaizen.shubhambhavatu.entity.master.Tehsil;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TehsilRepository extends JpaRepository<Tehsil, Long> {

    List<Tehsil> findByDistrictId(Long districtId);

    Optional<Tehsil> findByIdAndDistrictId(Long tehsilId, Long districtId);
}
