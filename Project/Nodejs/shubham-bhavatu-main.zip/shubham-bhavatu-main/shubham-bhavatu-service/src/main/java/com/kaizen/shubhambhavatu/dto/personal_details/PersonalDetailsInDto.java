package com.kaizen.shubhambhavatu.dto.personal_details;

import com.kaizen.shubhambhavatu.annotations.DateFormatValidator;
import com.kaizen.shubhambhavatu.annotations.ValueOfEnum;
import com.kaizen.shubhambhavatu.constants.Gender;
import com.kaizen.shubhambhavatu.constants.MaritalStatus;
import com.kaizen.shubhambhavatu.dto.BirthPlaceDto;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Getter
@Setter
public class PersonalDetailsInDto {

    private String middleName;

    @NotBlank(message = "{personalDetails.gender.NotBlank.message}")
    @ValueOfEnum(enumClass = Gender.class, message = "{maritalStatus.Invalid.message}")
    private String gender;

    @NotBlank(message = "{personalDetails.maritalStatus.NotBlank.message}")
    @ValueOfEnum(enumClass = MaritalStatus.class, message = "{maritalStatus.Invalid.message}")
    private String maritalStatus;

    private int numberOfChildren;
    @NotNull(message = "{personalDetails.motherTongueId.NotNull.message}")
    private Long motherTongueId;

    @NotBlank(message = "{personalDetails.birthTime.NotBlank.message}")
    @DateFormatValidator(pattern = "HH:mm")
    private String birthTime;

    @Email(message="Email format is invalid")
    private String emailId;
    @NotBlank(message = "{personalDetails.contactNumber.NotBlank.message}")
    private String contactNumber;
    private BirthPlaceDto birthPlaceDto;

}
