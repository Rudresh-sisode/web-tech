package com.kaizen.shubhambhavatu.constants;

public enum EatingHabits {
    VEGETARIAN("Vegetarian"),
    NON_VEGETARIAN("Non-Vegetarain"),
    EGGETARIAN("Eggetarian");

    private final String value;

    EatingHabits(String value) {
        this.value = value;
    }
}
