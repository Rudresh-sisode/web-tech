package com.kaizen.shubhambhavatu.entity;

import com.kaizen.shubhambhavatu.entity.audit.AuditEntity;
import com.kaizen.shubhambhavatu.listener.ShubhamBhavatuAuditListener;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "birth_place")
@Getter
@Setter
@ExcludeSuperclassListeners
@EntityListeners(ShubhamBhavatuAuditListener.class)
public class BirthPlace extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "town")
    private String town;

    @Column(name = "tehsil_id")
    private Long tehsilId;

    @Column(name = "district_id")
    private Long districtId;

    @Column(name = "pincode")
    private String pinCode;
}
