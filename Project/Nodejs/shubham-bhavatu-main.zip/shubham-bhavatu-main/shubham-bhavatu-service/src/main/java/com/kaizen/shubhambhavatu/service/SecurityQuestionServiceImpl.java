package com.kaizen.shubhambhavatu.service;

import com.kaizen.shubhambhavatu.entity.SecurityQuestion;
import com.kaizen.shubhambhavatu.repository.SecurityQuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SecurityQuestionServiceImpl implements SecurityQuestionService {

    @Autowired
    private SecurityQuestionRepository securityQuestionRepository;

    @Override
    public List<SecurityQuestion> getSecurityQuestions() {
        return securityQuestionRepository.getActiveSecurityQuestions();
    }
}
