package com.kaizen.shubhambhavatu.annotations.proessor;

import com.kaizen.shubhambhavatu.annotations.DateFormatValidator;
import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.ParseException;
import java.util.Date;

import static java.lang.Boolean.TRUE;
import static org.apache.commons.lang3.time.DateUtils.parseDateStrictly;

public class DateFormatValidatorAnnotationProcessor implements ConstraintValidator<DateFormatValidator, String> {

    private String pattern;
    private boolean isPastDate;

    @Override
    public void initialize(DateFormatValidator dateFormatValidator) {
        pattern = dateFormatValidator.pattern();
        isPastDate = dateFormatValidator.isPastDate();
    }

    @Override
    public boolean isValid(String date, ConstraintValidatorContext context) {
        return StringUtils.isEmpty(date) || isValidDate(date, pattern);
    }

    private boolean isValidDate(String date, String pattern) {
        try {
            Date parsedDate = parseDateStrictly(date, pattern);
            return isPastDate ? parsedDate.before(new Date()) : TRUE;
        } catch (ParseException ex) {
            return false;
        }
    }
}
