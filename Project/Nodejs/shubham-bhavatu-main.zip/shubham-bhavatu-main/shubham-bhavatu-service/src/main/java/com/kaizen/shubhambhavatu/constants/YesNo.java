package com.kaizen.shubhambhavatu.constants;

public enum YesNo {
    YES, NO;
}
