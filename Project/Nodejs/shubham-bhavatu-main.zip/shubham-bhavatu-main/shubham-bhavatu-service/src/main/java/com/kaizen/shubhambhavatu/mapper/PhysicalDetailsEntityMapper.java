package com.kaizen.shubhambhavatu.mapper;

import com.kaizen.shubhambhavatu.dto.physical_details.PhysicalDetailsDto;
import com.kaizen.shubhambhavatu.entity.PhysicalDetails;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface PhysicalDetailsEntityMapper {

    PhysicalDetails map(PhysicalDetailsDto physicalDetailsDto);
}
