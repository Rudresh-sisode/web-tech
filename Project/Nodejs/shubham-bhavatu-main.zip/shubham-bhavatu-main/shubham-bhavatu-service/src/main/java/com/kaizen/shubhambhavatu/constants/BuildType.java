package com.kaizen.shubhambhavatu.constants;

public enum BuildType {
    SLIM("Slim"),
    ATHLETIC("Athletic"),
    AVERAGE("Average"),
    HEALTHY("Healthy"),
    FATTY("Fatty");

    private final String value;

    BuildType(String value) {
        this.value = value;
    }
}
