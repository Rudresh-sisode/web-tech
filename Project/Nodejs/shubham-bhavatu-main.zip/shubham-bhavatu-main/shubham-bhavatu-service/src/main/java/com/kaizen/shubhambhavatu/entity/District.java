package com.kaizen.shubhambhavatu.entity;

import lombok.Getter;

import javax.persistence.*;

@Entity
@Getter
@Table(name = "district")
public class District {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String districtName;

    @Column(name = "state_id")
    private long stateId;
}
