package com.kaizen.shubhambhavatu.entity.master;

import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Getter
@NoArgsConstructor
@Table(name = "tehsil")
public class Tehsil {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String tehsilName;

    @Column(name = "district_id")
    private long districtId;

    public Tehsil(String tehsilName, Long districtId) {
        this.tehsilName = tehsilName;
        this.districtId = districtId;
    }
}
