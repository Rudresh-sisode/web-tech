package com.kaizen.shubhambhavatu.entity;

import com.kaizen.shubhambhavatu.constants.Gender;
import com.kaizen.shubhambhavatu.constants.MaritalStatus;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.*;

@Embeddable
@Getter
@Setter
public class PersonalDetails {
    @Column(name = "first_name")
    private String firstName;

    @Column(name = "middle_name")
    private String middleName;

    @Column(name = "last_name")
    private String lastName;

    @Enumerated(EnumType.STRING)
    @Column(name = "gender")
    @Type( type = "pgsql_enum" )
    private Gender gender;

    @Column(name = "marital_status")
    @Enumerated(EnumType.STRING)
    @Type( type = "pgsql_enum" )
    private MaritalStatus maritalStatus;

    @Column(name = "number_of_children")
    private int numberOfChildren;

    @Column(name = "mother_tongue_id")
    private Long motherTongueId;

    @Column(name = "birth_date")
    private String birthDate;

    @Column(name = "birth_time")
    private String birthTime;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "birth_place_id", referencedColumnName = "id")
    private BirthPlace birthPlace;

    @Column(name = "native_place")
    private String nativePlace;

    @Column(name = "email_id")
    private String emailId;

    @Column(name = "contact_number")
    private String contactNumber;
}
