package com.kaizen.shubhambhavatu.constants;

public enum DrinkingSmoking {
    YES, NO, OCCASIONAL;
}
