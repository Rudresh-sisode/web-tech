package com.kaizen.shubhambhavatu.listener;

import com.kaizen.shubhambhavatu.entity.audit.AuditEntity;
import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import static java.time.LocalDateTime.now;
import static org.apache.commons.lang3.StringUtils.isBlank;

@Configurable(autowire = Autowire.BY_TYPE, preConstruction = true)
public class ShubhamBhavatuAuditListener extends AuditingEntityListener {
    @Override
    @PrePersist
    public void touchForCreate(Object target) {
        AuditEntity auditEntity = (AuditEntity) target;

        if (isBlank(auditEntity.getCreatedBy())) {
            super.touchForCreate(auditEntity);
        } else {
            auditEntity.setCreatedDate(now());
        }
    }

    @Override
    @PreUpdate
    public void touchForUpdate(Object target) {
        AuditEntity auditEntity = (AuditEntity) target;

        if (isBlank(auditEntity.getUpdatedBy())) {
            super.touchForCreate(auditEntity);
        } else {
            auditEntity.setUpdatedDate(now());
        }
    }
}
