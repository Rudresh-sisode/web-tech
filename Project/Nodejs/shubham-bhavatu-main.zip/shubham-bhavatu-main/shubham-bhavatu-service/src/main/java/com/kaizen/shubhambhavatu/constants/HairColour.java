package com.kaizen.shubhambhavatu.constants;

public enum HairColour {
    BLACK("Black"),
    BLONDE("Blonde"),
    BROWN("Brown"),
    RED("Red"),
    SILVER("Silver"),
    SALT_AND_PEPPER("Salt and Pepper");

    private final String value;

    HairColour(String value) {
        this.value = value;
    }
}
