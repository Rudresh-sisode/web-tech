package com.kaizen.shubhambhavatu.audit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.AuditorAware;

import java.util.Optional;

public class AuditorAwareImpl implements AuditorAware<String> {

    @Value("${audit.user.name:shubham-bhavatu-rest-api}")
    private String auditUserName;

    @Override
    public Optional<String> getCurrentAuditor() {
        return Optional.of(this.auditUserName);
    }

}
