package com.kaizen.shubhambhavatu.service;

import com.kaizen.shubhambhavatu.entity.User;
import com.kaizen.shubhambhavatu.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public User registerUser(User user) {
        User registeredUser = userRepository.saveAndFlush(user);
        return registeredUser;
    }
}
