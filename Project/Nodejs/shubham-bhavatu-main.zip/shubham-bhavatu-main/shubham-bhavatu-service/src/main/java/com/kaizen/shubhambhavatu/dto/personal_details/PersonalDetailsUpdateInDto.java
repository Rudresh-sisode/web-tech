package com.kaizen.shubhambhavatu.dto.personal_details;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
public class PersonalDetailsUpdateInDto extends PersonalDetailsInDto {
    @NotBlank(message = "{candidateNumber.NotBlank.message}")
    private String candidateNumber;

    private String updatedBy;
}
