package com.kaizen.shubhambhavatu.dto.physical_details;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
public class PhysicalDetailsUpdateInDto extends PhysicalDetailsDto {
    @NotBlank(message = "{candidateNumber.NotBlank.message}")
    private String candidateNumber;

    private String updatedBy;
}
