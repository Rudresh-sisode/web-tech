package com.kaizen.shubhambhavatu.constants;

public enum SkinType {
    EXT_FAIR("Ext Fair"),
    FAIR("Fair"),
    MEDIUM("Medium"),
    OLIVE("Olive"),
    BROWN("Brown"),
    BLACK("Black");

    private final String value;

    SkinType(String value) {
        this.value = value;
    }
}
