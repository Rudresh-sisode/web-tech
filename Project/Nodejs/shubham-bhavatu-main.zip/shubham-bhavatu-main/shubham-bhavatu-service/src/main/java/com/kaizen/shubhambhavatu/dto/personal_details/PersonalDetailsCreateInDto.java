package com.kaizen.shubhambhavatu.dto.personal_details;

import com.kaizen.shubhambhavatu.annotations.DateFormatValidator;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
public class PersonalDetailsCreateInDto extends PersonalDetailsInDto {

    @NotBlank(message = "{personalDetails.firstName.NotBlank.message}")
    private String firstName;

    @NotBlank(message = "{personalDetails.lastName.NotBlank.message}")
    private String lastName;

    @NotBlank(message = "{personalDetails.birthDate.NotBlank.message}")
    @DateFormatValidator(pattern = "dd-MM-yyyy", isPastDate = true)
    private String birthDate;

    private String createdBy;
}
