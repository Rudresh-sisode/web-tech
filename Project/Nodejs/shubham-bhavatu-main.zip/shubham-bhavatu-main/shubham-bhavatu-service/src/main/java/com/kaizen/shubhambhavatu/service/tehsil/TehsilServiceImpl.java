package com.kaizen.shubhambhavatu.service.tehsil;

import com.kaizen.shubhambhavatu.dto.TehsilInDto;
import com.kaizen.shubhambhavatu.entity.District;
import com.kaizen.shubhambhavatu.entity.master.Tehsil;
import com.kaizen.shubhambhavatu.repository.TehsilRepository;
import com.kaizen.shubhambhavatu.service.district.DistrictService;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TehsilServiceImpl implements TehsilService {

    private final DistrictService districtService;
    private final TehsilRepository tehsilRepository;

    public TehsilServiceImpl(DistrictService districtService, TehsilRepository tehsilRepository) {
        this.districtService = districtService;
        this.tehsilRepository = tehsilRepository;
    }

    @Override
    public List<Tehsil> addTehsils(TehsilInDto tehsilInDto) {
        Long districtId;
        List<String> tehsilNameList = new ArrayList<>();
        if(tehsilInDto.getDistrictId() == 0 && tehsilInDto.getDistrictName().isEmpty() ) {
            throw new RuntimeException("DistrictId or DistrictName is required");
        }
        if(tehsilInDto.getDistrictId() != 0) {
            districtId = getDistrictId(Long.valueOf(tehsilInDto.getDistrictId()));
        } else {
            districtId = getDistrictId(tehsilInDto.getDistrictName());
        }
        tehsilInDto.getTehsilNames().forEach(tehsil ->
                tehsilNameList.addAll(Arrays.stream(tehsil.split("\n")).collect(Collectors.toList()))
        );
        List<Tehsil> tehsilList = tehsilNameList.stream()
                .map(tehsilName -> tehsilName.replaceAll("\\d+ ", ""))
                .sorted()
                .map(tehsil -> new Tehsil(tehsil, districtId))
                .collect(Collectors.toList());
        return tehsilRepository.saveAll(tehsilList);

    }

    @Override
    public List<Tehsil> getTehsilsByDistrictId(Long districtId) {
        districtService.getDistrictById(districtId);
        return tehsilRepository.findByDistrictId(districtId);
    }

    @Override
    public Tehsil getTehsilById(Long id) {
        Optional<Tehsil> tehsilOptional = tehsilRepository.findById(id);
        if (tehsilOptional.isPresent()) {
            return tehsilOptional.get();
        } else {
            throw new EntityNotFoundException("Tehsil with Id " + id + " does not exists");
        }
    }

    @Override
    public Optional<Tehsil> getTehsilByIdAndDistrictId(Long tehsilId, Long districtId) {
        return tehsilRepository.findByIdAndDistrictId(tehsilId, districtId);
    }

    private Long getDistrictId(Long districtId) {
        Optional<District> districtOptional = districtService.getDistrict(districtId);
        return districtOptional.map(District::getId).orElseThrow(() -> new RuntimeException("District not present in DB"));
    }

    private Long getDistrictId(String districtName) {
        Optional<District> districtOptional = districtService.getDistrict(districtName);
        return districtOptional.map(District::getId).orElseThrow(() -> new RuntimeException("District not present in DB"));
    }
}
