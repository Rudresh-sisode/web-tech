package com.kaizen.shubhambhavatu.service.district;

import com.kaizen.shubhambhavatu.entity.District;

import java.util.List;
import java.util.Optional;

public interface DistrictService {
    Optional<District> getDistrict(Long id);
    Optional<District> getDistrict(String districtName);

    List<District> getDistrictsByStateId(Long stateId);

    District getDistrictById(Long id);
}
