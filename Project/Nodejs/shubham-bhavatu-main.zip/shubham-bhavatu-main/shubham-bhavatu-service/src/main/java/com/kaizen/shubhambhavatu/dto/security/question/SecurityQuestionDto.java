package com.kaizen.shubhambhavatu.dto.security.question;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SecurityQuestionDto {
    private String id;
    private String question;
}
