package com.kaizen.shubhambhavatu.constants;

public enum Gender {
    MALE, FEMALE;
}
