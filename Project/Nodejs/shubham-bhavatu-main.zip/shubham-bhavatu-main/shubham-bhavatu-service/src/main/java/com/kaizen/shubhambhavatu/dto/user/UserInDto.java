package com.kaizen.shubhambhavatu.dto.user;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserInDto {
    private String firstName;
    private String lastName;
    private String email;
    private String mobileNumber;
    private String userName;
}
