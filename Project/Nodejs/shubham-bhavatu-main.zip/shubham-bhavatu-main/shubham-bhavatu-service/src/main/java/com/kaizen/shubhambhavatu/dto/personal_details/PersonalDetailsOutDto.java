package com.kaizen.shubhambhavatu.dto.personal_details;

import com.kaizen.shubhambhavatu.dto.BirthPlaceDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PersonalDetailsOutDto {
    private String firstName;
    private String middleName;
    private String lastName;
    private String birthDate;
    private String candidateNumber;
    private String gender;
    private String maritalStatus;
    private int numberOfChildren;
    private Long motherTongueId;
    private String birthTime;
    private String emailId;
    private String contactNumber;
    private BirthPlaceDto birthPlaceDto;
}
