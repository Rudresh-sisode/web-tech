package com.kaizen.shubhambhavatu.service;

import com.kaizen.shubhambhavatu.entity.User;

public interface UserService {
    User registerUser(User user);
}
