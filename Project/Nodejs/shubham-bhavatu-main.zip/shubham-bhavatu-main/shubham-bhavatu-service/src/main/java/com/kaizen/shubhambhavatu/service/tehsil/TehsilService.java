package com.kaizen.shubhambhavatu.service.tehsil;

import com.kaizen.shubhambhavatu.dto.TehsilInDto;
import com.kaizen.shubhambhavatu.entity.master.Tehsil;

import java.util.List;
import java.util.Optional;

public interface TehsilService {
    List<Tehsil> addTehsils(TehsilInDto tehsilInDto);

    List<Tehsil> getTehsilsByDistrictId(Long districtId);

    Tehsil getTehsilById(Long id);

    Optional<Tehsil> getTehsilByIdAndDistrictId(Long tehsilId, Long districtId);
}
