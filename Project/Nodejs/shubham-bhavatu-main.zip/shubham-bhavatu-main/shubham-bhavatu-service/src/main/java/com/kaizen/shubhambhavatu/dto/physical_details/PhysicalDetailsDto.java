package com.kaizen.shubhambhavatu.dto.physical_details;

import com.kaizen.shubhambhavatu.annotations.ValueOfEnum;
import com.kaizen.shubhambhavatu.constants.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PhysicalDetailsDto {
    private double height;

    private int weight;

    @ValueOfEnum(enumClass = BuildType.class, message = "{buildType.Invalid.message}")
    private String build;

    @ValueOfEnum(enumClass = BloodGroup.class, message = "{bloodGroup.Invalid.message}")
    private String bloodGroup;

    @ValueOfEnum(enumClass = YesNo.class, message = "{contactLenses.Invalid.message}")
    private String contactLenses;

    @ValueOfEnum(enumClass = DrinkingSmoking.class, message = "{smoking.Invalid.message}")
    private String smoking;

    @ValueOfEnum(enumClass = DrinkingSmoking.class, message = "{drinking.Invalid.message}")
    private String drinking;

    @ValueOfEnum(enumClass = EyeColour.class, message = "{eyeColour.Invalid.message}")
    private String eyeColour;

    @ValueOfEnum(enumClass = HairColour.class, message = "{hairColour.Invalid.message}")
    private String hairColour;

    @ValueOfEnum(enumClass = SkinType.class, message = "{skinType.Invalid.message}")
    private String skinColour;

    @ValueOfEnum(enumClass = EatingHabits.class, message = "{eatingHabits.Invalid.message}")
    private String eatingHabits;

    @ValueOfEnum(enumClass = PhysicalStatus.class, message = "{physicalStatus.Invalid.message}")
    private String physicalStatus;

    private String disabilityDescription;

}
