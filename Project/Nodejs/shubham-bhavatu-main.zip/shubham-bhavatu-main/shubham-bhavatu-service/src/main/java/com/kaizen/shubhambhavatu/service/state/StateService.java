package com.kaizen.shubhambhavatu.service.state;

import com.kaizen.shubhambhavatu.entity.master.State;

public interface StateService {
    State getStateById(Long id);
}
