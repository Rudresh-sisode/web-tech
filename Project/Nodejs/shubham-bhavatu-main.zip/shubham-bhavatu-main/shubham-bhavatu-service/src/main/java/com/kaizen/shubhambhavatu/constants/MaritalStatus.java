package com.kaizen.shubhambhavatu.constants;

public enum MaritalStatus {
    SINGLE,DIVORCED, WIDOWED, SEPARATED;
}
