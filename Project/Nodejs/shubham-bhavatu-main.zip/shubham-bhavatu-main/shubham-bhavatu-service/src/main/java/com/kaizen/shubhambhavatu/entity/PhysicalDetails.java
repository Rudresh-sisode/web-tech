package com.kaizen.shubhambhavatu.entity;

import com.kaizen.shubhambhavatu.constants.*;
import com.kaizen.shubhambhavatu.converter.BloodGroupConverter;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.*;

@Embeddable
@Getter
@Setter
public class PhysicalDetails {

    @Column(name = "height")
    private double height = 0d;

    @Column(name = "weight")
    private int weight;

    @Column(name = "build")
    @Enumerated(EnumType.STRING)
    @Type(type = "pgsql_enum")
    private BuildType build;

    @Column(name = "blood_group")
    @Convert(converter = BloodGroupConverter.class)
    private BloodGroup bloodGroup;

    @Column(name = "contact_lenses")
    @Enumerated(EnumType.STRING)
    @Type(type = "pgsql_enum")
    private YesNo contactLenses;

    @Column(name = "smoking")
    @Enumerated(EnumType.STRING)
    @Type(type = "pgsql_enum")
    private DrinkingSmoking smoking;

    @Column(name = "drinking")
    @Enumerated(EnumType.STRING)
    @Type(type = "pgsql_enum")
    private DrinkingSmoking drinking;

    @Column(name = "eye_colour")
    @Enumerated(EnumType.STRING)
    @Type(type = "pgsql_enum")
    private EyeColour eyeColour;

    @Column(name = "hair_colour")
    @Enumerated(EnumType.STRING)
    @Type(type = "pgsql_enum")
    private HairColour hairColour;

    @Column(name = "skin_colour")
    @Enumerated(EnumType.STRING)
    @Type(type = "pgsql_enum")
    private SkinType skinColour;

    @Column(name = "eating_habits")
    @Enumerated(EnumType.STRING)
    @Type(type = "pgsql_enum")
    private EatingHabits eatingHabits;

    @Column(name = "physical_status")
    @Enumerated(EnumType.STRING)
    @Type(type = "pgsql_enum")
    private PhysicalStatus physicalStatus;

    @Column(name = "disability_description")
    private String disabilityDescription;
}
