package com.kaizen.shubhambhavatu.converter;

import com.kaizen.shubhambhavatu.constants.BloodGroup;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class BloodGroupConverter implements AttributeConverter<BloodGroup, String> {

    @Override
    public String convertToDatabaseColumn(BloodGroup attribute) {
        return attribute == null ? null : attribute.getValue();
    }

    @Override
    public BloodGroup convertToEntityAttribute(String value) {
        return value == null ? null : BloodGroup.findByValue(value);
    }
}