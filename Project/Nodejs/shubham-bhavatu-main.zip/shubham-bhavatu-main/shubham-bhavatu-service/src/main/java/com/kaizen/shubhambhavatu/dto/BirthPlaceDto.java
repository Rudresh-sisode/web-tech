package com.kaizen.shubhambhavatu.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BirthPlaceDto {
    private String town;
    private Long tehsilId;
    private Long districtId;
    private String pinCode;
}