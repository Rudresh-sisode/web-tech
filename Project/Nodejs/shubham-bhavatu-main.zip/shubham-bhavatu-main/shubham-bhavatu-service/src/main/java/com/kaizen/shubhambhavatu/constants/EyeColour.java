package com.kaizen.shubhambhavatu.constants;

public enum EyeColour {

    BLACK("Black"),
    BLUE("Blue"),
    BROWN("Brown"),
    GREEN("Green"),
    HAZEL("Hazel"),
    LIGHT_BROWN("Light-Brown");

    private final String value;

    EyeColour(String value) {
        this.value = value;
    }
}
