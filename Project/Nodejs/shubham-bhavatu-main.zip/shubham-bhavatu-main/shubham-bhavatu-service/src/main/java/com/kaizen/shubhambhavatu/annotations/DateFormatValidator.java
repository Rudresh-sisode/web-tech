package com.kaizen.shubhambhavatu.annotations;

import com.kaizen.shubhambhavatu.annotations.proessor.DateFormatValidatorAnnotationProcessor;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = DateFormatValidatorAnnotationProcessor.class)
public @interface DateFormatValidator {
    String pattern();

    String message() default "Invalid date format";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    boolean isPastDate() default false;
}
