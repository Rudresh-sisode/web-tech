package com.kaizen.shubhambhavatu.service;

import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsCreateInDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsOutDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsUpdateInDto;
import com.kaizen.shubhambhavatu.dto.physical_details.PhysicalDetailsOutDto;
import com.kaizen.shubhambhavatu.dto.physical_details.PhysicalDetailsUpdateInDto;


public interface CandidateService {
    PersonalDetailsOutDto registerCandidate(PersonalDetailsCreateInDto personalDetailsDto);

    PersonalDetailsOutDto updatePersonalDetails(PersonalDetailsUpdateInDto personalDetailsUpdateInDto);

    PhysicalDetailsOutDto updatePhysicalDetails(PhysicalDetailsUpdateInDto physicalDetailsUpdateInDto);
}
