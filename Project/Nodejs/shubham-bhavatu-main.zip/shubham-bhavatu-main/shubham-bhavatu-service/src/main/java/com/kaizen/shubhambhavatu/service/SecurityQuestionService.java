package com.kaizen.shubhambhavatu.service;

import com.kaizen.shubhambhavatu.entity.SecurityQuestion;

import java.util.List;

public interface SecurityQuestionService {
    List<SecurityQuestion> getSecurityQuestions();
}
