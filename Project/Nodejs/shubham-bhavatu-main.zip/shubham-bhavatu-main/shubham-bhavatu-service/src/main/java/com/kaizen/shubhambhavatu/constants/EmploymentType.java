package com.kaizen.shubhambhavatu.constants;

public enum EmploymentType {
    GOVT("Government"),
    PVT("Private"),
    DEFENCE("Defence"),
    SELF_EMPLOYED("Self-Employed");

    private final String value;

    EmploymentType(String value) {
        this.value = value;
    }
}
