package com.kaizen.shubhambhavatu.repository;

import com.kaizen.shubhambhavatu.entity.CandidateDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CandidateDetailsRepository extends JpaRepository<CandidateDetails, Long> {

    @Query(value = "select nextval('candidate_number_sequence')", nativeQuery = true)
    Long getNextCandidateNumberSequence();

    Optional<CandidateDetails> findByCandidateNumber(String candidateNumber);

    Optional<CandidateDetails> findByPersonalDetailsFirstNameAndPersonalDetailsLastNameAndPersonalDetailsBirthDate(String firstName, String lastName, String birthDate);
}
