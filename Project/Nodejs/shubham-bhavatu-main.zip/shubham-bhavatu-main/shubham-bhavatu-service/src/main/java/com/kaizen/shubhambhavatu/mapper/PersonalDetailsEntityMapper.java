package com.kaizen.shubhambhavatu.mapper;

import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsCreateInDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsUpdateInDto;
import com.kaizen.shubhambhavatu.entity.PersonalDetails;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PersonalDetailsEntityMapper {
    @Mapping(source = "birthPlaceDto.districtId", target = "birthPlace.districtId")
    @Mapping(source = "birthPlaceDto.tehsilId", target = "birthPlace.tehsilId")
    @Mapping(source = "birthPlaceDto.pinCode", target = "birthPlace.pinCode")
    @Mapping(source = "birthPlaceDto.town", target = "birthPlace.town")
    PersonalDetails map(PersonalDetailsCreateInDto personalDetailsDto);

    @Mapping(source = "birthPlaceDto.districtId", target = "birthPlace.districtId")
    @Mapping(source = "birthPlaceDto.tehsilId", target = "birthPlace.tehsilId")
    @Mapping(source = "birthPlaceDto.pinCode", target = "birthPlace.pinCode")
    @Mapping(source = "birthPlaceDto.town", target = "birthPlace.town")
    PersonalDetails mapUpdate(PersonalDetailsUpdateInDto personalDetailsUpdateInDto);
}
