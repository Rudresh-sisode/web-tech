package com.kaizen.shubhambhavatu.constants;

public enum PhysicalStatus {
    NORMAL("Normal"),
    DISABLE("Disable");

    private final String value;

    PhysicalStatus(String value) {
        this.value = value;
    }
}
