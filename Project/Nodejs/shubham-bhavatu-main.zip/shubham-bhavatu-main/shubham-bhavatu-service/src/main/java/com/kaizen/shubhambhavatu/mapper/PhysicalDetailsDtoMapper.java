package com.kaizen.shubhambhavatu.mapper;

import com.kaizen.shubhambhavatu.dto.physical_details.PhysicalDetailsOutDto;
import com.kaizen.shubhambhavatu.entity.CandidateDetails;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PhysicalDetailsDtoMapper {
    @Mapping(source = "physicalDetails.height", target = "height")
    @Mapping(source = "physicalDetails.weight", target = "weight")
    @Mapping(source = "physicalDetails.bloodGroup", target = "bloodGroup")
    @Mapping(source = "physicalDetails.contactLenses", target = "contactLenses")
    @Mapping(source = "physicalDetails.smoking", target = "smoking")
    @Mapping(source = "physicalDetails.drinking", target = "drinking")
    @Mapping(source = "physicalDetails.eyeColour", target = "eyeColour")
    @Mapping(source = "physicalDetails.hairColour", target = "hairColour")
    @Mapping(source = "physicalDetails.skinColour", target = "skinColour")
    @Mapping(source = "physicalDetails.eatingHabits", target = "eatingHabits")
    @Mapping(source = "physicalDetails.physicalStatus", target = "physicalStatus")
    @Mapping(source = "physicalDetails.disabilityDescription", target = "disabilityDescription")
    @Mapping(source = "physicalDetails.build", target = "build")
    PhysicalDetailsOutDto map(CandidateDetails candidateDetails);
}

