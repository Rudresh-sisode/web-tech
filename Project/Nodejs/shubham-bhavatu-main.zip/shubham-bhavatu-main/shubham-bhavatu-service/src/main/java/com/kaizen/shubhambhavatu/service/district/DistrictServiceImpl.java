package com.kaizen.shubhambhavatu.service.district;

import com.kaizen.shubhambhavatu.entity.District;
import com.kaizen.shubhambhavatu.repository.DistrictRepository;
import com.kaizen.shubhambhavatu.service.state.StateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class DistrictServiceImpl implements DistrictService{

    private final DistrictRepository districtRepository;
    private final StateService stateService;

    @Autowired
    public DistrictServiceImpl(DistrictRepository districtRepository, StateService stateService) {
        this.districtRepository = districtRepository;
        this.stateService = stateService;
    }

    @Override
    public Optional<District> getDistrict(Long id) {
        return districtRepository.findById(id);
    }

    @Override
    public Optional<District> getDistrict(String districtName) {
        return districtRepository.findByDistrictName(districtName);
    }

    @Override
    public List<District> getDistrictsByStateId(Long stateId) {
        stateService.getStateById(stateId);
        return districtRepository.findByStateId(stateId);
    }

    @Override
    public District getDistrictById(Long id) {
        Optional<District> districtOptional = districtRepository.findById(id);
        return districtOptional.orElseThrow(() ->new EntityNotFoundException("District with id "+ id +" does not exists"));
    }
}
