package com.kaizen.shubhambhavatu.entity;

import com.kaizen.shubhambhavatu.entity.audit.AuditEntity;
import com.kaizen.shubhambhavatu.listener.ShubhamBhavatuAuditListener;
import com.vladmihalcea.hibernate.type.basic.PostgreSQLEnumType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@TypeDef(
        name = "pgsql_enum",
        typeClass = PostgreSQLEnumType.class
)
@ExcludeSuperclassListeners
@EntityListeners(ShubhamBhavatuAuditListener.class)
public class CandidateDetails extends AuditEntity {

    @Column(name = "candidate_number")
    private String candidateNumber;

    @Embedded
    private PersonalDetails personalDetails;

    @Embedded
    private PhysicalDetails physicalDetails;
}
