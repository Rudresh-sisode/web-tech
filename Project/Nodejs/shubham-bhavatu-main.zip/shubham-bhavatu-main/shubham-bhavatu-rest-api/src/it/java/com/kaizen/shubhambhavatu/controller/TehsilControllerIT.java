package com.kaizen.shubhambhavatu.controller;

import org.junit.Test;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class TehsilControllerIT extends AbstractControllerIT {
    @Test
    public void shouldReturnOkWhenGetTehsilByIdCalledWithExistingTehsilId() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.get("/api/tehsils/1260")).andExpect(status().isNotFound());
    }
}
