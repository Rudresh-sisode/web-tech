package com.kaizen.shubhambhavatu.config.context;

import com.kaizen.shubhambhavatu.ShubhamBhavatuRestApiApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(ShubhamBhavatuRestApiApplication.class)
public class TestApplicationContext {
}
