package com.kaizen.shubhambhavatu.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kaizen.shubhambhavatu.AbstractIntegrationTest;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;

public abstract class AbstractControllerIT extends AbstractIntegrationTest {

    @Autowired
    protected WebApplicationContext webApplicationContext;

    protected MockMvc mockMvc;

    protected ObjectMapper mapper = new ObjectMapper();

    @Before
    public void init() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    protected Object parseJsonToObject(String json, Class aClass) throws IOException {
        return mapper.readValue(json, aClass);
    }

    protected String parseObjectToJson(Object object) throws JsonProcessingException {
        return mapper.writeValueAsString(object);
    }
}
