package com.kaizen.shubhambhavatu.controller;

import com.kaizen.shubhambhavatu.service.UserService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api
@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserService userService;

    /*@PostMapping(value = "/users", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UserOutDto> registerUser(@Valid @RequestBody UserInDto userInDto) {
        User user = getUser(userInDto);
        User registeredUser = userService.registerUser(user);
        return ResponseEntity.ok(getUserOutDto(registeredUser));
    }*/
}
