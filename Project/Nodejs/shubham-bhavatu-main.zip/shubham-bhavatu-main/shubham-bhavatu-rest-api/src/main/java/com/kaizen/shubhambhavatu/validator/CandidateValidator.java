package com.kaizen.shubhambhavatu.validator;

import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsInDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.Validator;

@Component
public class CandidateValidator extends BaseValidator<PersonalDetailsInDto> {
    private Validator validator;

    @Autowired
    private void setValidator(Validator validator) {
        this.validator = validator;
    }

    @Override
    protected Validator getValidator() {
        return this.validator;
    }

    @Override
    protected Class<?> getClassType() {
        return PersonalDetailsInDto.class;
    }
}
