package com.kaizen.shubhambhavatu.error;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public interface ApiError {
    default Error getApiError(String reasonCode, String description) {
        return Error.builder()
                .reasonCode(reasonCode)
                .description(description)
                .build();
    }

    default ResponseEntity<Object> getErrorResponse(ErrorList errorList, HttpStatus httpStatus) {
        Errors errors = new Errors(errorList);
        return new ResponseEntity<>(errors, httpStatus);
    }
}
