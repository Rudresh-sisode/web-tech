package com.kaizen.shubhambhavatu.error;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

@Getter
@AllArgsConstructor
public class ErrorList {
    private List<Error> errors;
}
