package com.kaizen.shubhambhavatu.controller;

import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsCreateInDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsInDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsOutDto;
import com.kaizen.shubhambhavatu.dto.personal_details.PersonalDetailsUpdateInDto;
import com.kaizen.shubhambhavatu.dto.physical_details.PhysicalDetailsOutDto;
import com.kaizen.shubhambhavatu.dto.physical_details.PhysicalDetailsUpdateInDto;
import com.kaizen.shubhambhavatu.service.CandidateService;
import com.kaizen.shubhambhavatu.validator.CandidateValidator;
import io.swagger.annotations.Api;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Api
@RestController
@RequestMapping("/api/candidates")
public class CandidateController {

    private final CandidateService candidateService;

    private final CandidateValidator candidateValidator;

    public CandidateController(CandidateService candidateService, CandidateValidator candidateValidator) {
        this.candidateService = candidateService;
        this.candidateValidator = candidateValidator;
    }

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        if (candidateValidator != null && binder.getTarget() instanceof PersonalDetailsInDto) {
            binder.setValidator(candidateValidator);
        }
    }

    @PostMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<PersonalDetailsOutDto> registerCandidate(@RequestBody @Validated PersonalDetailsCreateInDto personalDetailsDto) {
        return new ResponseEntity<>(candidateService.registerCandidate(personalDetailsDto), HttpStatus.CREATED);
    }

    @PutMapping(produces = APPLICATION_JSON_VALUE, path = "/personalDetails")
    public ResponseEntity<PersonalDetailsOutDto> updatePersonalDetails(@RequestBody @Validated PersonalDetailsUpdateInDto personalDetailsUpdateInDto) {
        return ResponseEntity.ok(candidateService.updatePersonalDetails(personalDetailsUpdateInDto));
    }

    @PutMapping(produces = APPLICATION_JSON_VALUE, path = "/physicalDetails")
    public ResponseEntity<PhysicalDetailsOutDto> updatePhysicalDetails(@RequestBody @Validated PhysicalDetailsUpdateInDto physicalDetailsUpdateInDto) {
        return ResponseEntity.ok(candidateService.updatePhysicalDetails(physicalDetailsUpdateInDto));
    }
}
