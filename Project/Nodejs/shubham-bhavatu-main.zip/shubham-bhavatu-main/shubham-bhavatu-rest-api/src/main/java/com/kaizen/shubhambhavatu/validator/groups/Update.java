package com.kaizen.shubhambhavatu.validator.groups;

public interface Update {
}
