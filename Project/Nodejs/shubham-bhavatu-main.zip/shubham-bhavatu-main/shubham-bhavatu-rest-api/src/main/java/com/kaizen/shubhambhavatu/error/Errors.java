package com.kaizen.shubhambhavatu.error;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class Errors {
    private ErrorList errorList;
}
