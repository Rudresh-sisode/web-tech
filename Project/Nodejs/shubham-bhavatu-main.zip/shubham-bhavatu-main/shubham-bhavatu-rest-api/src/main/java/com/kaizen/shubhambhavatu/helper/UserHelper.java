package com.kaizen.shubhambhavatu.helper;

import com.kaizen.shubhambhavatu.dto.user.UserInDto;
import com.kaizen.shubhambhavatu.dto.user.UserOutDto;
import com.kaizen.shubhambhavatu.entity.User;

public class UserHelper {

    //To-do use mapstruct instead
    public static User getUser(UserInDto userInDto) {
        User user = new User();
        user.setFirstName(userInDto.getFirstName());
        user.setLastName(userInDto.getLastName());
        user.setEmail(userInDto.getEmail());
        user.setMobileNumber(userInDto.getMobileNumber());
        user.setUserName(userInDto.getUserName());
        return user;
    }

    //To-do use mapstruct instead
    public static UserOutDto getUserOutDto(User user) {
        UserOutDto userOutDto = new UserOutDto();
        userOutDto.setFirstName(user.getFirstName());
        userOutDto.setLastName(user.getLastName());
        userOutDto.setEmail(user.getEmail());
        userOutDto.setMobileNumber(user.getMobileNumber());
        userOutDto.setUserName(user.getUserName());
        return userOutDto;
    }
}
