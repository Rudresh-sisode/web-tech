package com.kaizen.shubhambhavatu.controller;

import com.kaizen.shubhambhavatu.dto.TehsilInDto;
import com.kaizen.shubhambhavatu.entity.master.Tehsil;
import com.kaizen.shubhambhavatu.service.tehsil.TehsilService;
import io.swagger.annotations.Api;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityNotFoundException;
import java.util.ArrayList;
import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Api
@RestController
@RequestMapping("/api/tehsils")
public class TehsilController {

    private final TehsilService tehsilService;

    public TehsilController(TehsilService tehsilService) {
        this.tehsilService = tehsilService;
    }

    @PostMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Tehsil>> addTehsils(@RequestBody List<TehsilInDto> tehsilInDto) {
        List<Tehsil> tehsilList = new ArrayList<>();
        tehsilInDto.forEach(dto -> {
            List<Tehsil> tList = tehsilService.addTehsils(dto);
            tehsilList.addAll(tList);
        });
        return ResponseEntity.ok(tehsilList);
    }

    @GetMapping(produces = APPLICATION_JSON_VALUE, path = "/districtId/{districtId}")
    public ResponseEntity<List<Tehsil>> getTehsilsByDistrictId(@PathVariable("districtId") Long districtId) {
        return ResponseEntity.ok(tehsilService.getTehsilsByDistrictId(districtId));
    }

    @GetMapping(produces = APPLICATION_JSON_VALUE, path = "/{id}")
    public ResponseEntity<Tehsil> getTehsilById(@PathVariable("id") Long id) {
        try {
            return ResponseEntity.ok(tehsilService.getTehsilById(id));
        } catch (EntityNotFoundException ex) {
            return ResponseEntity.notFound().build();
        }
    }
}
