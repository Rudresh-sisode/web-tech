package com.kaizen.shubhambhavatu.error;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class Error {
    private String reasonCode;
    private String description;
    private boolean recoverable;
    private String details;
}
