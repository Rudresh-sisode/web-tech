package com.kaizen.shubhambhavatu.controller;

import com.kaizen.shubhambhavatu.dto.security.question.SecurityQuestionDto;
import com.kaizen.shubhambhavatu.entity.SecurityQuestion;
import com.kaizen.shubhambhavatu.helper.SecurityQuestionHelper;
import com.kaizen.shubhambhavatu.service.SecurityQuestionService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api
@RestController
@RequestMapping("/api")
public class SecurityQuestionsController {

    @Autowired
    SecurityQuestionService securityQuestionService;

    @GetMapping(value="/security-questions", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<SecurityQuestionDto>> getSecurityQuestions() {
        List<SecurityQuestion> securityQuestionList = securityQuestionService.getSecurityQuestions();
        return ResponseEntity.ok(SecurityQuestionHelper.getSecurityQuestionDtoList(securityQuestionList));
    }
}
