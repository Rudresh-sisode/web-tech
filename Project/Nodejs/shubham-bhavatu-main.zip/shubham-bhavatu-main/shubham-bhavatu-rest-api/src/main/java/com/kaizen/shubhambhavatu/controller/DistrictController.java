package com.kaizen.shubhambhavatu.controller;

import com.kaizen.shubhambhavatu.entity.District;
import com.kaizen.shubhambhavatu.service.district.DistrictService;
import io.swagger.annotations.Api;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.persistence.EntityNotFoundException;
import java.util.List;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Api
@RestController
@RequestMapping("/api/districts")
public class DistrictController {
    private final DistrictService districtService;

    public DistrictController(DistrictService districtService) {
        this.districtService = districtService;
    }

    @GetMapping(produces = APPLICATION_JSON_VALUE, path = "/stateId/{stateId}")
    public ResponseEntity<List<District>> getDistrictsByStateId(@PathVariable("stateId") Long stateId) {
        return ResponseEntity.ok(districtService.getDistrictsByStateId(stateId));
    }

    @GetMapping(produces = APPLICATION_JSON_VALUE, path = "/{id}")
    public ResponseEntity<District> getDistrictById(@PathVariable("id") Long id) {
        try {
            return ResponseEntity.ok(districtService.getDistrictById(id));
        } catch (EntityNotFoundException ex) {
            return ResponseEntity.notFound().build();
        }
    }
}
