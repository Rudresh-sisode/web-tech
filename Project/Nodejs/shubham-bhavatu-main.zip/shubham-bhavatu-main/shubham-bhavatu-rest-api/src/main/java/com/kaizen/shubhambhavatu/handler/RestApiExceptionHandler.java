package com.kaizen.shubhambhavatu.handler;

import com.kaizen.shubhambhavatu.error.ApiGenericExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class RestApiExceptionHandler implements ApiGenericExceptionHandler {
}
