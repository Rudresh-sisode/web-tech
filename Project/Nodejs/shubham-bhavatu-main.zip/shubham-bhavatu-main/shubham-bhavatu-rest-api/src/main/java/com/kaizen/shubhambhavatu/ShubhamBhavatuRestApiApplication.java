package com.kaizen.shubhambhavatu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShubhamBhavatuRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShubhamBhavatuRestApiApplication.class, args);
	}

}
