package com.kaizen.shubhambhavatu.error;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityNotFoundException;
import java.util.ArrayList;
import java.util.List;

public interface ApiGenericExceptionHandler extends ApiError {
    @ExceptionHandler(MethodArgumentNotValidException.class)
    default ResponseEntity<Object> handleMethodArgumentNotValidException(MethodArgumentNotValidException exception) {
        List<Error> errors = new ArrayList<>();
        exception.getBindingResult().getAllErrors().forEach(fieldError -> {
            Error error = getApiError(fieldError.getCode(), fieldError.getDefaultMessage());
            errors.add(error);
        });
        return getErrorResponse(new ErrorList(errors), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(EntityExistsException.class)
    default ResponseEntity<Object> handleEntityExistsException(EntityExistsException exception) {
        List<Error> errors = new ArrayList<>();
        Error error = getApiError("Entity already exists", exception.getMessage());
        errors.add(error);
        return getErrorResponse(new ErrorList(errors), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(EntityNotFoundException.class)
    default ResponseEntity<Object> handleEntityExistsException(EntityNotFoundException exception) {
        List<Error> errors = new ArrayList<>();
        Error error = getApiError("Entity not found", exception.getMessage());
        errors.add(error);
        return getErrorResponse(new ErrorList(errors), HttpStatus.BAD_REQUEST);
    }
}
