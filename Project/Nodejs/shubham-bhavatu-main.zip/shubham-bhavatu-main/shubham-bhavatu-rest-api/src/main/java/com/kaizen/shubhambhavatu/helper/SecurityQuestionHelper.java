package com.kaizen.shubhambhavatu.helper;

import com.kaizen.shubhambhavatu.dto.security.question.SecurityQuestionDto;
import com.kaizen.shubhambhavatu.entity.SecurityQuestion;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

import static lombok.AccessLevel.PRIVATE;

@NoArgsConstructor(access = PRIVATE)
public class SecurityQuestionHelper {

    public static List<SecurityQuestionDto> getSecurityQuestionDtoList(List<SecurityQuestion> securityQuestionList) {
        return securityQuestionList.stream()
                .map(SecurityQuestionHelper::getSecurityQuestionDto)
                .collect(Collectors.toList());
    }

    public static SecurityQuestionDto getSecurityQuestionDto(SecurityQuestion securityQuestion) {
        SecurityQuestionDto securityQuestionDto = new SecurityQuestionDto();
        securityQuestionDto.setId(String.valueOf(securityQuestion.getId()));
        securityQuestionDto.setQuestion(securityQuestion.getQuestion());
        return securityQuestionDto;
    }
}
