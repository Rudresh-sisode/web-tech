package com.kaizen.shubhambhavatu.validator;

import com.kaizen.shubhambhavatu.validator.groups.Create;
import com.kaizen.shubhambhavatu.validator.groups.Update;
import org.springframework.validation.Errors;
import org.springframework.validation.SmartValidator;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.groups.Default;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static java.util.Objects.nonNull;

public abstract class BaseValidator<T> implements SmartValidator {

    protected abstract Validator getValidator();

    @Override
    public void validate(Object toValidate, Errors errors) {
        this.validate(toValidate, errors, Default.class);
    }

    @Override
    public void validate(Object toValidate, Errors errors, Object... validationGroups) {
        validateRequiredFields(toValidate, errors, validationGroups);
        if (!errors.hasErrors()) {
            Map<Class<?>, Consumer<BaseValidator<T>>> groupValidator = getGroupValidator((T) toValidate, errors);
            Stream.of(validationGroups).forEach(group -> {
                if (groupValidator.containsKey(group)) {
                    groupValidator.get(group).accept(this);
                }
            });
        }
    }

    private Map<Class<?>, Consumer<BaseValidator<T>>> getGroupValidator(T toValidate, Errors errors) {
        Map<Class<?>, Consumer<BaseValidator<T>>> groupValidator = new HashMap<>();
        groupValidator.put(Create.class, validate -> validateCreate(toValidate, errors));
        groupValidator.put(Update.class, validate -> validateCreate(toValidate, errors));
        groupValidator.put(Default.class, validate -> validateCreate(toValidate, errors));
        return groupValidator;
    }

    protected void validateCreate(T toValidate, Errors errors) {
    }

    private void validateRequiredFields(Object toValidate, Errors errors, Object... validationGroups) {
        Set<ConstraintViolation<Object>> constraintViolations = getValidator().validate(toValidate, getValidationGroups(validationGroups));
        if (nonNull(constraintViolations)) {
            constraintViolations.forEach(
                    constraintViolation ->
                            errors.rejectValue(constraintViolation.getPropertyPath().toString(), "MISSING_REQUIRED_FIELD", constraintViolation.getMessage()));
        }
    }

    private Class<?>[] getValidationGroups(Object... validationGroups) {
        return Stream.of(validationGroups).map(Class.class::cast).toArray(Class[]::new);
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return this.getClassType().isAssignableFrom(aClass);
    }

    protected abstract Class<?> getClassType();
}
