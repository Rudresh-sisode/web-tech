package com.kaizen.shubhambhavatuflyway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShubhamBhavatuFlywayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShubhamBhavatuFlywayApplication.class, args);
	}

}
