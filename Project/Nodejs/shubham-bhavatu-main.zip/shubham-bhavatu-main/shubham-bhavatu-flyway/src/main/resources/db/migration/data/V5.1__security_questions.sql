INSERT INTO security_question (id, question, is_active) VALUES
(1, 'Who is your favorite author?', true),
(2, 'What is the birth place of your mother?', true),
(3, 'What is the first name of your best friend in high school?', true),
(4, 'What is the maiden name of your grandmother', true),
(5, 'What are the last five digits of your driving license number?', true),
(6, 'In what town or city was your first full time job?', true),
(7, 'Who was your favorite teacher?', true),
(8, 'What is the name of your first school?', true),
(9, 'Name your favorite colour', true),
(10, 'Who is your favorite sportsperson?', true);
