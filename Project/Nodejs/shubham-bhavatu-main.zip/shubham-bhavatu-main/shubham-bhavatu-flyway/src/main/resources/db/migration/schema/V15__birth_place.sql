CREATE TABLE if not exists birth_place (
    id SERIAL,
    town varchar(255) not null,
    tehsil_id int,
    district_id int not null,
    pincode varchar(255),
    CONSTRAINT birth_place_pkey PRIMARY KEY (id),
    constraint birth_place_fk01 foreign key (tehsil_id) references tehsil(id),
    constraint birth_place_fk02 foreign key (district_id) references district(id)
);