CREATE TABLE if not exists gotra (
    id SERIAL,
    gotra_name varchar(255) not null,
    CONSTRAINT gotra_pkey PRIMARY KEY (id)
);