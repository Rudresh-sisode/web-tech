CREATE TABLE if not exists candidate
(
    id SERIAL,
    first_name character varying(255) not null,
    last_name character varying(255) not null,
    date_of_birth date,
    email character varying(255) UNIQUE,
    mobile_num character varying(255) UNIQUE,
    user_name character varying(255) UNIQUE,
    CONSTRAINT candidate_pkey PRIMARY KEY (id)
)
