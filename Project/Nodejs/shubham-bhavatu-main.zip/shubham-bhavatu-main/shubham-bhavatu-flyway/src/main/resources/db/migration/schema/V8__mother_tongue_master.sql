CREATE TABLE if not exists mother_tongue_master (
    id SERIAL,
    mother_tongue varchar(255) not null,
    CONSTRAINT mother_tongue_master_pkey PRIMARY KEY (id)
);