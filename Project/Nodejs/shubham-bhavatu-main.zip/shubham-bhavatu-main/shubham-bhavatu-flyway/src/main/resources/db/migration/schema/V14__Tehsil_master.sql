CREATE TABLE if not exists tehsil (
    id SERIAL,
    name varchar(255) not null,
    district_id int,
    CONSTRAINT tehsil_pkey PRIMARY KEY (id),
    constraint tehsil_fk01 foreign key (district_id) references district(id)
);