CREATE TYPE gender AS ENUM ('MALE', 'FEMALE');

CREATE TYPE marital_status AS ENUM ('SINGLE', 'DIVORCED', 'WIDOWED', 'SEPARATED');

CREATE TYPE yes_no AS ENUM ('YES', 'NO');

CREATE TYPE drinking_smoking AS ENUM ('YES', 'NO', 'OCCASIONAL');

CREATE TYPE blood_group AS ENUM ('A Positive', 'A Negative', 'B Positive', 'B Negative', 'AB Positive', 'AB Negative', 'O Positive', 'O Negative');

CREATE TYPE eating_habits AS ENUM ('Vegetarian','Non-Vegetarian','Eggetarian');

CREATE TYPE physical_status AS ENUM('NORMAL', 'DISABLE');

CREATE TYPE employment_type AS ENUM('GOVT', 'PVT', 'DEFENCE', 'SELF_EMPLOYED');

CREATE TYPE family_type AS ENUM('NUCLEUS', 'JOINT');

CREATE TYPE build_type AS ENUM('SLIM', 'ATHLETIC', 'AVERAGE', 'HEALTHY', 'FATTY');

CREATE TYPE eye_colour_type AS ENUM('BLACK', 'BLUE', 'BROWN', 'GREEN', 'HAZEL', 'LIGHT BROWN');

CREATE TYPE hair_colour_type AS ENUM('BLACK', 'BLONDE', 'BROWN', 'RED', 'SILVER', 'SALT AND PEPPER');

CREATE TYPE skin_type AS ENUM ('EXT FAIR', 'FAIR', 'MEDIUM', 'OLIVE', 'BROWN', 'BLACK');