create sequence candidate_number_sequence increment by 1
minvalue 100000;