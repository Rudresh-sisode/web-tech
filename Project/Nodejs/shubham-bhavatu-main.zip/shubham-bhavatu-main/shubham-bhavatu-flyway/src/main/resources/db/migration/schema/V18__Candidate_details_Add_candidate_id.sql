alter table candidate_details
add column candidate_number varchar(255) not null;