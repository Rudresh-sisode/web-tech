CREATE TABLE if not exists education_master (
    id SERIAL,
    education varchar(255) not null,
    description varchar(255),
    CONSTRAINT education_master_pkey PRIMARY KEY (id)
)