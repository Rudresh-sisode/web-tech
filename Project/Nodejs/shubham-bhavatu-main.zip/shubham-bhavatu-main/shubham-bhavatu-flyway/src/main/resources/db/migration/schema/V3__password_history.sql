CREATE TABLE if not exists password_history
(
id SERIAL,
user_id bigint not null,
password character varying(255) not null,
CONSTRAINT password_history_pkey PRIMARY KEY (id),
CONSTRAINT fk_password_history_user_id FOREIGN KEY(user_id) REFERENCES candidate(id)
)