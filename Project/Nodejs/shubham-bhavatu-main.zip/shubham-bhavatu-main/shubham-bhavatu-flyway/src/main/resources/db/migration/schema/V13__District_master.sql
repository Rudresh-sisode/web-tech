CREATE TABLE if not exists district (
    id SERIAL,
    name varchar(255) not null,
    state_id int,
    CONSTRAINT district_pkey PRIMARY KEY (id),
    constraint district_fk01 foreign key (state_id) references state(id)
);