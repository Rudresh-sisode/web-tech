alter table candidate_details
drop  column birth_place;

alter table candidate_details
add column birth_place_id smallint not null;

alter table candidate_details
add constraint candidate_details_fk04 foreign key(birth_place_id) references birth_place(id)