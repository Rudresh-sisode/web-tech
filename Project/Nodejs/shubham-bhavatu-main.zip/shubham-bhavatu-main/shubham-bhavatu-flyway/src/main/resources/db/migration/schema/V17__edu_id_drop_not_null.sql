alter table candidate_details
alter column birth_place_id drop not null;

alter table candidate_details
alter column education_id drop not null;

alter table candidate_details
alter column education_id drop default;

