CREATE TABLE if not exists state (
    id SERIAL,
    name varchar(255) not null,
    country_id int,
    CONSTRAINT state_pkey PRIMARY KEY (id),
    constraint state_fk01 foreign key (country_id) references country(id)
);