INSERT INTO district values
(729, 'Narayanpet',33),
(730, 'Mulugu',33);