alter TYPE eating_habits rename VALUE 'Vegetarian' TO 'VEGETARIAN';
alter TYPE eating_habits rename VALUE 'Non-Vegetarian' TO 'NON_VEGETARIAN';
alter TYPE eating_habits rename VALUE 'Eggetarian' TO 'EGGETARIAN';