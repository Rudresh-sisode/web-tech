CREATE TABLE if not exists candidate_details
(
    id SERIAL,
    first_name character varying(500) not null,
    middle_name character varying(500),
    last_name character varying(500) not null,
    gender gender,
    marital_status marital_status,
    number_of_children smallint default 0,
    mother_tongue_id smallint not null,
    birth_date character varying(500) not null, --(PII data)
    birth_time character varying(255) not null, -- (non PII Data) (rethink on data type)
    birth_place character varying(500) not null, -- (PII Data)
    native_place character varying(500),
    email_id character varying(500),
    contact_number character varying(500) not null,
    mamkul character varying(255),
    hobbies character varying(500),
    height smallint not null default 0 ,
    weight smallint not null default 0 ,
    build build_type,
    contact_lenses yes_no,
    blood_group blood_group,
    drinking drinking_smoking,
    smoking drinking_smoking,
    eye_colour eye_colour_type,
    hair_colour hair_colour_type,
    skin_colour skin_type,
    eating_habits eating_habits,
    physical_status physical_status,
    disability_description character varying(1000),
    education_id smallint not null default 0, -- default 0 and 0 will be empty because it will not be added in first screen
    education_details varchar(500),
    university varchar(500),
    is_employed yes_no,
    employment_type employment_type,
    work_at varchar(500),
    designation varchar(500),
    work_location varchar(500), --Can be converted to address
    monthly_income varchar(500), -- rethink on data type
    father_name character varying(500),
    contact_number_of_father character varying(500),
    mother_name character varying(500),
    contact_number_of_mother character varying(500),
    present_address character varying(1000),
    married_sisters smallint,
    unmarried_sisters smallint,
    married_brothers smallint,
    unmarried_brothers smallint,
    -- religion it will be added in next steps
    -- caste it will be added in next steps
    gotra_id smallint,
    primary key (id),
    Constraint candidate_details_fk01 foreign key (education_id) references education_master(ID),
    constraint candidate_details_fk02 foreign key (mother_tongue_id) references mother_tongue_master(ID),
    constraint candidate_details_fk03 foreign key (gotra_id) references gotra(id)
)