CREATE TABLE if not exists security_question
(
id SERIAL,
question character varying(255),
CONSTRAINT security_question_pkey PRIMARY KEY (id)
)
