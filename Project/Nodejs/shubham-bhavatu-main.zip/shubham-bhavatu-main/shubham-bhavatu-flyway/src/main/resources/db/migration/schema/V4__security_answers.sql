CREATE TABLE if not exists security_answers
(
id SERIAL,
user_id bigint not null,
question_id bigint not null,
answer character varying(255) not null,
CONSTRAINT security_answers_pkey PRIMARY KEY (id),
CONSTRAINT fk_security_answers_user_id FOREIGN KEY(user_id) REFERENCES candidate(id),
CONSTRAINT fk_security_answers_question_id FOREIGN KEY(question_id) REFERENCES security_question(id)
)