ALTER TYPE blood_group RENAME VALUE 'A Positive' TO 'A+';
ALTER TYPE blood_group RENAME VALUE 'A Negative' TO 'A-';
ALTER TYPE blood_group RENAME VALUE 'B Positive' TO 'B+';
ALTER TYPE blood_group RENAME VALUE 'B Negative' TO 'B-';
ALTER TYPE blood_group RENAME VALUE 'AB Positive' TO 'AB+';
ALTER TYPE blood_group RENAME VALUE 'AB Negative' TO 'AB-';
ALTER TYPE blood_group RENAME VALUE 'O Positive' TO 'O+';
ALTER TYPE blood_group RENAME VALUE 'O Negative' TO 'O-';
