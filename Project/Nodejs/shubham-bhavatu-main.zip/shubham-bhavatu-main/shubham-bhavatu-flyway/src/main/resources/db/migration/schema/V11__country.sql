CREATE TABLE if not exists country (
    id SERIAL,
    name varchar(255) not null,
    CONSTRAINT country_pkey PRIMARY KEY (id)
);