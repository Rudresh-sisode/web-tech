package com.kaizen.shubhambhavatuflyway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShubhamBhavatuFlywayApplicationTests {

	/*@Test
	void contextLoads() {
	}*/

}
